package principal.control;

public class GestorControles {
	public static final Teclado teclado = new Teclado();

}
